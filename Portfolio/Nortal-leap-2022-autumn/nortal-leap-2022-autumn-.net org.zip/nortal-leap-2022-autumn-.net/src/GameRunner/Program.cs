﻿using GameRunner;

IGame game = new Game();

var result = game.Run(@"TestData\map1.txt");