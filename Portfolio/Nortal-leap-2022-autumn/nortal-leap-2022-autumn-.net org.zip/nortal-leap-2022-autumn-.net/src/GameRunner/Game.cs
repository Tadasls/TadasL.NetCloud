﻿namespace GameRunner;

public class Game : IGame
{
    public int Run(string filePath)
    {
        // TODO: start your journey here

        return -1;
    }
}
