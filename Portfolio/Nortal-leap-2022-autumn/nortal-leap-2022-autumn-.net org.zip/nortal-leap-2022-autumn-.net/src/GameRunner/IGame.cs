﻿namespace GameRunner;

public interface IGame
{
    int Run(string filePath);
}